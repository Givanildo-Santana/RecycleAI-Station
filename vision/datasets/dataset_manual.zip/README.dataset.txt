# dataset_manual > 2025-11-16 4:17pm
https://universe.roboflow.com/nassif/dataset_manual-b8k4k

Provided by a Roboflow user
License: MIT

